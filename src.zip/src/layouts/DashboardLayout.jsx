import { Outlet } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";

export default function DashboardLayout() {
  return (
    <div className="flex h-screen">
      {/* Sidebar – ALWAYS visible */}
      <Sidebar />

      {/* Right side */}
      <div className="flex-1 flex flex-col">
        {/* Header – ALWAYS visible */}
        <Header />

        {/* Page content changes here */}
        <main className="flex-1 overflow-y-auto bg-gray-50">
          <Outlet />
        </main>
      </div>
    </div>
  );
}