

// import { useState } from "react";
// import { Upload } from "lucide-react";
// import * as XLSX from "xlsx";

// export default function UploadResultModal({ onClose, onUpload }) {
//   const [file, setFile] = useState(null);
//   const [error, setError] = useState("");

//   const handleFileChange = (e) => {
//     setFile(e.target.files[0]);
//     setError("");
//   };

//   const handleProcess = () => {
//     if (!file) {
//       setError("Please select an Excel file");
//       return;
//     }

//     const reader = new FileReader();

//     reader.onload = (e) => {
//       const data = new Uint8Array(e.target.result);

//       const workbook = XLSX.read(data, { type: "array" });
//       const sheetName = workbook.SheetNames[0];
//       const sheet = workbook.Sheets[sheetName];

//       // ✅ Excel -> JSON
//       const excelData = XLSX.utils.sheet_to_json(sheet);
//       onUpload(excelData);
//     onClose();

//     //   console.log("Parsed Excel Data:", excelData);

//       /*
//         Expected Excel columns:
//         Email | Score | Result | Remarks

//         Example output:
//         [
//           { Email: "sarah@email.com", Score: 68, Result: "Pending", Remarks: "Needs improvement" }
//         ]
//       */

//       // 👉 NEXT STEPS (later):
//       // 1. Match email with candidate list
//       // 2. Update status (Pass/Fail/Pending)
//       // 3. Update stage
//       // 4. Call backend API

//       onClose();
//     };

//     reader.readAsArrayBuffer(file);
//   };

//   return (
//     <div className="space-y-6">
//       {/* Header */}
//       <div className="flex justify-between items-center">
//         <h2 className="text-xl font-semibold">Upload Result Dump File</h2>
//         <button onClick={onClose} className="text-xl">×</button>
//       </div>

//       {error && (
//         <div className="bg-red-50 text-red-600 p-3 rounded text-sm">
//           {error}
//         </div>
//       )}

//       {/* Upload Box */}
//       <div className="border-2 border-dashed rounded-xl p-10 flex flex-col items-center text-center text-gray-500">
//         <Upload size={32} />
//         <p className="mt-3">Upload Excel file with candidate results</p>
//         <p className="text-sm mt-1">
//           Expected format: Email, Score, Result, Remarks
//         </p>

//         <label className="mt-4 bg-white border px-4 py-2 rounded cursor-pointer">
//           Choose File
//           <input
//             type="file"
//             accept=".xls,.xlsx"
//             onChange={handleFileChange}
//             className="hidden"
//           />
//         </label>

//         {file && (
//           <p className="mt-2 text-sm text-black">
//             Selected: {file.name}
//           </p>
//         )}
//       </div>

//       {/* Actions */}
//       <div className="flex justify-end gap-4">
//         <button
//           onClick={onClose}
//           className="w-1/2 border py-2 rounded-lg"
//         >
//           Cancel
//         </button>

//         <button
//           onClick={handleProcess}
//           className="w-1/2 bg-black text-white py-2 rounded-lg"
//         >
//           Process Results
//         </button>
//       </div>
//     </div>
//   );
// }


import { useState } from "react";
import { Upload } from "lucide-react";
import { uploadCandidatesExcel } from "../api/candidateApi";

export default function UploadResultModal({ onClose, onUploadSuccess }) {
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setError("");
  };

  const handleProcess = async () => {
    if (!file) {
      setError("Please select an Excel file");
      return;
    }

    try {
      setLoading(true);
      const savedCandidates = await uploadCandidatesExcel(file);

      // ✅ Notify parent to refresh list
      onUploadSuccess(savedCandidates);

      onClose();
    } catch (err) {
      setError("Upload failed");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Upload Result Dump File</h2>
        <button onClick={onClose} className="text-xl">×</button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded text-sm">
          {error}
        </div>
      )}

      <div className="border-2 border-dashed rounded-xl p-10 flex flex-col items-center text-center text-gray-500">
        <Upload size={32} />
        <p className="mt-3">Upload Excel file (.xls / .xlsx)</p>

        <label className="mt-4 bg-white border px-4 py-2 rounded cursor-pointer">
          Choose File
          <input
            type="file"
            accept=".xls,.xlsx"
            onChange={handleFileChange}
            className="hidden"
          />
        </label>

        {file && (
          <p className="mt-2 text-sm text-black">
            Selected: {file.name}
          </p>
        )}
      </div>

      <div className="flex justify-end gap-4">
        <button
          onClick={onClose}
          className="w-1/2 border py-2 rounded-lg"
        >
          Cancel
        </button>

        <button
          onClick={handleProcess}
          className="w-1/2 bg-black text-white py-2 rounded-lg"
          disabled={loading}
        >
          {loading ? "Uploading…" : "Process Results"}
        </button>
      </div>
    </div>
  );
}