// import { useState, useEffect } from "react";

// export default function AddCandidateModal({
//   onClose,
//   onAdd,
//   initialData
// }) {
//   const [form, setForm] = useState({
//     name: "",
//     email: "",
//     position: "",
//     source: "GTD",
//     practice: "Practice 1",
//     type: "Bench",
//     // stage: "Level 1",
//     // status: "Pending",
//     applied: "",          // ✅ added
//   });

//   const [error, setError] = useState("");

//   // ✅ LOAD DATA WHEN EDITING (3 dots)
//   useEffect(() => {
//     if (initialData) {
//       setForm(initialData);
//     }
//   }, [initialData]);

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//     setError("");
//   };

//   const handleSubmit = () => {
//     if (!form.name || !form.email || !form.position) {
//       setError("Please fill all required fields");
//       return;
//     }

//     onAdd({
//       ...form,
//       // ✅ Use selected applied date OR fallback to today
//       applied:
//         form.applied ||
//         new Date().toLocaleDateString("en-GB"), // dd/mm/yyyy
//     });
//   };

//   return (
//     <div className="space-y-5">
//       {/* Header */}
//       <div className="flex justify-between items-center">
//         <h2 className="text-xl font-semibold">
//           {initialData ? "Edit Candidate" : "Add New Candidate"}
//         </h2>
//         <button onClick={onClose} className="text-xl">×</button>
//       </div>

//       {/* Error */}
//       {error && (
//         <div className="bg-red-50 text-red-600 p-3 rounded text-sm">
//           {error}
//         </div>
//       )}

//       <input
//         name="name"
//         value={form.name}
//         onChange={handleChange}
//         placeholder="Full Name *"
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       />

//       <input
//         name="email"
//         value={form.email}
//         onChange={handleChange}
//         placeholder="Email *"
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       />

//       <input
//         name="position"
//         value={form.position}
//         onChange={handleChange}
//         placeholder="Position *"
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       />

//       <select
//         name="source"
//         value={form.source}
//         onChange={handleChange}
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       >
//         <option>GTD</option>
//         <option>Talentio</option>
//       </select>

//       <select
//         name="practice"
//         value={form.practice}
//         onChange={handleChange}
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       >
//         <option>Practice 1</option>
//         <option>Practice 2</option>
//         <option>Practice 3</option>
//       </select>

//       <select
//         name="type"
//         value={form.type}
//         onChange={handleChange}
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       >
//         <option>Bench</option>
//         <option>Rotation</option>
//       </select>

//       {/* ✅ Applied Date field (NEW) */}
//       <input
//         type="date"
//         name="applied"
//         value={form.applied || ""}
//         onChange={handleChange}
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       />

//       {/* <select
//         name="stage"
//         value={form.stage}
//         onChange={handleChange}
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       >
//         <option>Level 1</option>
//         <option>Level 2</option>
//         <option>Level 3</option>
//         <option>Grooming</option>
//       </select>

//       <select
//         name="status"
//         value={form.status}
//         onChange={handleChange}
//         className="w-full p-3 bg-gray-100 rounded-lg"
//       >
//         <option>Pending</option>
//         <option>Pass</option>
//         <option>Fail</option>
//       </select> */}

//       {/* Actions */}
//       <div className="flex gap-4 pt-6">
//         <button
//           onClick={onClose}
//           className="w-1/2 border py-2 rounded-lg"
//         >
//           Cancel
//         </button>
//         <button
//           onClick={handleSubmit}
//           className="w-1/2 bg-black text-white py-2 rounded-lg"
//         >
//           {initialData ? "Update Candidate" : "Add Candidate"}
//         </button>
//       </div>
//     </div>
//   );
// }


import { useState, useEffect } from "react";

export default function AddCandidateModal({
  onClose,
  onAdd,
  initialData
}) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    position: "",
    source: "GTD",
    practice: "Practice 1",
    type: "Bench",
    applied: "",
  });

  const [error, setError] = useState("");

  useEffect(() => {
    if (initialData) {
      setForm(initialData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError("");
  };

  const handleSubmit = () => {
    if (!form.name || !form.email || !form.position) {
      setError("Please fill all required fields");
      return;
    }

    onAdd({
      ...form,
      applied: form.applied || new Date().toISOString().split("T")[0],
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">
          {initialData ? "Edit Candidate" : "Add New Candidate"}
        </h2>
        <button onClick={onClose} className="text-xl">×</button>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-3 rounded text-sm">
          {error}
        </div>
      )}

      <input name="name" value={form.name} onChange={handleChange}
        placeholder="Full Name *" className="w-full p-3 bg-gray-100 rounded-lg" />

      <input name="email" value={form.email} onChange={handleChange}
        placeholder="Email *" className="w-full p-3 bg-gray-100 rounded-lg" />

      <input name="position" value={form.position} onChange={handleChange}
        placeholder="Position *" className="w-full p-3 bg-gray-100 rounded-lg" />

      <select name="source" value={form.source}
        onChange={handleChange} className="w-full p-3 bg-gray-100 rounded-lg">
        <option>GTD</option>
        <option>Talentio</option>
      </select>

      <select name="practice" value={form.practice}
        onChange={handleChange} className="w-full p-3 bg-gray-100 rounded-lg">
        <option>Practice 1</option>
        <option>Practice 2</option>
        <option>Practice 3</option>
      </select>

      <select name="type" value={form.type}
        onChange={handleChange} className="w-full p-3 bg-gray-100 rounded-lg">
        <option>Bench</option>
        <option>Rotation</option>
      </select>

      <input type="date" name="applied" value={form.applied || ""}
        onChange={handleChange} className="w-full p-3 bg-gray-100 rounded-lg" />

      <div className="flex gap-4 pt-6">
        <button onClick={onClose}
          className="w-1/2 border py-2 rounded-lg">Cancel</button>
        <button onClick={handleSubmit}
          className="w-1/2 bg-black text-white py-2 rounded-lg">
          {initialData ? "Update Candidate" : "Add Candidate"}
        </button>
      </div>
    </div>
  );
}
