
// import { useState } from "react";
// import { Clock, Video, MoreVertical, Send, X } from "lucide-react";
// import ScheduleMeeting from "./ScheduleMeeting";

// export default function Meetings() {
//   const [open, setOpen] = useState(false);
//   const [meetings, setMeetings] = useState([]);
//   const [editingIndex, setEditingIndex] = useState(null);
//   const [menuIndex, setMenuIndex] = useState(null);

//   // ✅ NEW
//   const [sentStatus, setSentStatus] = useState({});
//   const [confirmIndex, setConfirmIndex] = useState(null);

//   const handleAddOrUpdate = (meeting) => {
//     if (editingIndex !== null) {
//       const updated = [...meetings];
//       updated[editingIndex] = meeting;
//       setMeetings(updated);
//       setEditingIndex(null);
//     } else {
//       setMeetings((prev) => [...prev, meeting]);
//     }
//     setOpen(false);
//   };

//   const handleEdit = (index) => {
//     setEditingIndex(index);
//     setOpen(true);
//     setMenuIndex(null);
//   };

//   const handleDelete = (index) => {
//     if (!window.confirm("Are you sure you want to delete this meeting?")) return;
//     setMeetings((prev) => prev.filter((_, i) => i !== index));
//     setMenuIndex(null);
//   };

//   // ✅ Final confirmation
//   const confirmSendMeeting = () => {
//     setSentStatus((prev) => ({
//       ...prev,
//       [confirmIndex]: true,
//     }));
//     setConfirmIndex(null);
//   };

//   return (
//     <div className="p-6 space-y-6">
//       {/* Header */}
//       <div className="flex justify-between items-center">
//         <div>
//           <h1 className="text-2xl font-semibold">Meeting Schedule</h1>
//           <p className="text-sm text-gray-500">
//             Manage interviews and assessments
//           </p>
//         </div>

//         <button
//           onClick={() => {
//             setEditingIndex(null);
//             setOpen(true);
//           }}
//           className="bg-black text-white px-4 py-2 rounded-lg"
//         >
//           + Schedule Meeting
//         </button>
//       </div>

//       {/* Meetings List */}
//       <div className="bg-white border rounded-xl p-5 space-y-4">
//         <h2 className="text-lg font-semibold">Upcoming Meetings</h2>

//         {meetings.length === 0 ? (
//           <p className="text-gray-400">No meetings scheduled yet.</p>
//         ) : (
//           meetings.map((m, index) => (
//             <div
//               key={index}
//               className="border rounded-xl p-4 flex justify-between relative"
//             >
//               {/* Info */}
//               <div>
//                 <div className="flex gap-2">
//                   <h3 className="font-semibold">{m.interviewType}</h3>
//                   <span className="text-xs px-2 py-1 border rounded-full">
//                     {m.duration} min
//                   </span>
//                 </div>

//                 <p className="text-sm text-gray-500 mt-1">
//                   {m.date} at {m.time}
//                 </p>

//                 <div className="flex gap-4 text-sm text-gray-500 mt-2">
//                   <span className="flex items-center gap-1">
//                     <Video size={14} /> {m.location}
//                   </span>
//                   <span className="flex items-center gap-1">
//                     <Clock size={14} /> {m.interviewer}
//                   </span>
//                 </div>
//               </div>

//               {/* ✅ Send Meeting */}
//               <div className="absolute right-12 top-4">
//                 {!sentStatus[index] ? (
//                   <button
//                     onClick={() => setConfirmIndex(index)}
//                     className="bg-black text-white px-3 py-1.5 rounded-lg text-sm flex gap-2"
//                   >
//                     <Send size={14} /> Send Meeting
//                   </button>
//                 ) : (
//                   <span className="text-green-600 font-medium text-sm">
//                     ✅ Meeting Schedule Sent
//                   </span>
//                 )}
//               </div>

//               {/* Menu */}
//               <div className="relative">
//                 <button
//                   onClick={() =>
//                     setMenuIndex(menuIndex === index ? null : index)
//                   }
//                   className="p-1 rounded hover:bg-gray-100"
//                 >
//                   <MoreVertical size={18} />
//                 </button>

//                 {menuIndex === index && (
//                   <div className="absolute right-0 mt-2 bg-white border rounded shadow w-32 z-20">
//                     <button
//                       onClick={() => handleEdit(index)}
//                       className="block w-full px-4 py-2 text-left hover:bg-gray-100"
//                     >
//                       Edit
//                     </button>
//                     <button
//                       onClick={() => handleDelete(index)}
//                       className="block w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100"
//                     >
//                       Delete
//                     </button>
//                   </div>
//                 )}
//               </div>
//             </div>
//           ))
//         )}

//         {Object.values(sentStatus).includes(true) && (
//           <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
//             Meeting schedule email sent successfully.
//           </div>
//         )}
//       </div>

//       {/* ✅ CONFIRM SEND MEETING MODAL */}
//       {confirmIndex !== null && (
//         <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
//           <div className="bg-white w-[520px] rounded-2xl p-6 relative">
//             <button
//               onClick={() => setConfirmIndex(null)}
//               className="absolute right-4 top-4 text-gray-400"
//             >
//               <X size={18} />
//             </button>

//             <h2 className="text-xl font-semibold mb-6">
//               Send Meeting Schedule
//             </h2>

//             <div className="bg-gray-50 rounded-xl p-5 space-y-3 mb-6">
//               <p><b>Candidate:</b> Emma Williams</p>
//               <p><b>Interview:</b> {meetings[confirmIndex]?.interviewType}</p>
//               <p><b>Date & Time:</b> {meetings[confirmIndex]?.date} at {meetings[confirmIndex]?.time}</p>
//             </div>

//             <div className="flex justify-end gap-4">
//               <button
//                 onClick={() => setConfirmIndex(null)}
//                 className="px-6 py-3 border rounded-xl"
//               >
//                 Cancel
//               </button>
//               <button
//                 onClick={confirmSendMeeting}
//                 className="px-8 py-3 bg-black text-white rounded-xl"
//               >
//                 Send Meeting
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* Schedule Meeting Modal */}
//       {open && (
//         <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
//           <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden">
//             <div className="overflow-y-auto max-h-[90vh] p-6">
//               <ScheduleMeeting
//                 initialData={
//                   editingIndex !== null ? meetings[editingIndex] : null
//                 }
//                 onSchedule={handleAddOrUpdate}
//                 onClose={() => setOpen(false)}
//               />
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }


// import { useState } from "react";
// import { Clock, Video, MoreVertical, Send, X } from "lucide-react";
// import ScheduleMeeting from "./ScheduleMeeting";

// export default function Meetings() {
//   const [open, setOpen] = useState(false);
//   const [meetings, setMeetings] = useState([]);
//   const [editingIndex, setEditingIndex] = useState(null);
//   const [menuIndex, setMenuIndex] = useState(null);

//   // ✅ Track meeting email sent status
//   const [sentStatus, setSentStatus] = useState({});
//   const [confirmIndex, setConfirmIndex] = useState(null);

//   const handleAddOrUpdate = (meeting) => {
//     if (editingIndex !== null) {
//       const updated = [...meetings];
//       updated[editingIndex] = meeting;
//       setMeetings(updated);
//       setEditingIndex(null);
//     } else {
//       setMeetings((prev) => [...prev, meeting]);
//     }
//     setOpen(false);
//   };

//   const handleEdit = (index) => {
//     setEditingIndex(index);
//     setOpen(true);
//     setMenuIndex(null);
//   };

//   const handleDelete = (index) => {
//     if (!window.confirm("Are you sure you want to delete this meeting?")) return;
//     setMeetings((prev) => prev.filter((_, i) => i !== index));
//     setMenuIndex(null);
//   };

//   // ✅ Final confirmation (frontend only)
//   const confirmSendMeeting = () => {
//     setSentStatus((prev) => ({
//       ...prev,
//       [confirmIndex]: true,
//     }));
//     setConfirmIndex(null);
//   };

//   return (
//     <div className="p-6 space-y-6">
//       {/* Header */}
//       <div className="flex justify-between items-center">
//         <div>
//           <h1 className="text-2xl font-semibold">Meeting Schedule</h1>
//           <p className="text-sm text-gray-500">
//             Manage interviews and assessments
//           </p>
//         </div>

//         <button
//           onClick={() => {
//             setEditingIndex(null);
//             setOpen(true);
//           }}
//           className="bg-black text-white px-4 py-2 rounded-lg"
//         >
//           + Schedule Meeting
//         </button>
//       </div>

//       {/* Meetings List */}
//       <div className="bg-white border rounded-xl p-5 space-y-4">
//         <h2 className="text-lg font-semibold">Upcoming Meetings</h2>

//         {meetings.length === 0 ? (
//           <p className="text-gray-400">No meetings scheduled yet.</p>
//         ) : (
//           meetings.map((m, index) => (
//             <div
//               key={index}
//               className="border rounded-xl p-4 flex justify-between relative"
//             >
//               {/* Info */}
//               <div>
//                 <div className="flex gap-2 items-center">
//                   <h3 className="font-semibold">{m.interviewType}</h3>
//                   <span className="text-xs px-2 py-1 border rounded-full">
//                     {m.duration} min
//                   </span>
//                 </div>

//                 <p className="text-sm text-gray-500 mt-1">
//                   {m.date} at {m.time}
//                 </p>

//                 <div className="flex gap-4 text-sm text-gray-500 mt-2">
//                   <span className="flex items-center gap-1">
//                     <Video size={14} /> {m.location}
//                   </span>
//                   <span className="flex items-center gap-1">
//                     <Clock size={14} /> {m.interviewer}
//                   </span>
//                 </div>
//               </div>

//               {/* ✅ Send Meeting */}
//               <div className="absolute right-12 top-4">
//                 {!sentStatus[index] ? (
//                   <button
//                     onClick={() => setConfirmIndex(index)}
//                     className="bg-black text-white px-3 py-1.5 rounded-lg text-sm flex gap-2"
//                   >
//                     <Send size={14} />
//                     Send Meeting
//                   </button>
//                 ) : (
//                   <span className="text-green-600 font-medium text-sm">
//                     ✅ Meeting Schedule Sent
//                   </span>
//                 )}
//               </div>

//               {/* 3-dot menu */}
//               <div className="relative">
//                 <button
//                   onClick={() =>
//                     setMenuIndex(menuIndex === index ? null : index)
//                   }
//                   className="p-1 rounded hover:bg-gray-100"
//                 >
//                   <MoreVertical size={18} />
//                 </button>

//                 {menuIndex === index && (
//                   <div className="absolute right-0 mt-2 bg-white border rounded shadow w-32 z-20">
//                     <button
//                       onClick={() => handleEdit(index)}
//                       className="block w-full px-4 py-2 text-left hover:bg-gray-100"
//                     >
//                       Edit
//                     </button>
//                     <button
//                       onClick={() => handleDelete(index)}
//                       className="block w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100"
//                     >
//                       Delete
//                     </button>
//                   </div>
//                 )}
//               </div>
//             </div>
//           ))
//         )}

//         {/* ✅ Success Message */}
//         {Object.values(sentStatus).includes(true) && (
//           <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
//             Meeting schedule email sent successfully.
//           </div>
//         )}
//       </div>

//       {/* ✅ CONFIRM SEND MEETING MODAL */}
//       {confirmIndex !== null && (
//         <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
//           <div className="bg-white w-[520px] rounded-2xl p-6 relative">
//             <button
//               onClick={() => setConfirmIndex(null)}
//               className="absolute right-4 top-4 text-gray-400"
//             >
//               <X size={18} />
//             </button>

//             <h2 className="text-xl font-semibold mb-6">
//               Send Meeting Schedule
//             </h2>

//             {/* ✅ Candidate + Meeting Details */}
//             <div className="bg-gray-50 rounded-xl p-5 space-y-3 mb-6 text-sm">
//               <p>
//                 <span className="text-gray-600">Candidate:</span>{" "}
//                 <span className="font-medium">
//                   {meetings[confirmIndex]?.candidateName}
//                 </span>
//               </p>
//               <p>
//                 <span className="text-gray-600">Position:</span>{" "}
//                 <span className="font-medium">
//                   {meetings[confirmIndex]?.position}
//                 </span>
//               </p>
//               <p>
//                 <span className="text-gray-600">Email:</span>{" "}
//                 <span className="font-medium">
//                   {meetings[confirmIndex]?.email}
//                 </span>
//               </p>
//               <hr />
//               <p>
//                 <span className="text-gray-600">Interview:</span>{" "}
//                 <span className="font-medium">
//                   {meetings[confirmIndex]?.interviewType}
//                 </span>
//               </p>
//               <p>
//                 <span className="text-gray-600">Date & Time:</span>{" "}
//                 <span className="font-medium">
//                   {meetings[confirmIndex]?.date} at{" "}
//                   {meetings[confirmIndex]?.time}
//                 </span>
//               </p>
//             </div>

//             <div className="flex justify-end gap-4">
//               <button
//                 onClick={() => setConfirmIndex(null)}
//                 className="px-6 py-3 border rounded-xl"
//               >
//                 Cancel
//               </button>
//               <button
//                 onClick={confirmSendMeeting}
//                 className="px-8 py-3 bg-black text-white rounded-xl"
//               >
//                 Send Meeting
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       {/* ✅ Schedule Meeting Modal */}
//       {open && (
//         <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
//           <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden">
//             <div className="overflow-y-auto max-h-[90vh] p-6">
//               <ScheduleMeeting
//                 initialData={
//                   editingIndex !== null ? meetings[editingIndex] : null
//                 }
//                 onSchedule={handleAddOrUpdate}
//                 onClose={() => setOpen(false)}
//               />
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

import { useState } from "react";
import { Clock, Video, MoreVertical, Send, X } from "lucide-react";
import ScheduleMeeting from "./ScheduleMeeting";

export default function Meetings() {
  const [open, setOpen] = useState(false);
  const [meetings, setMeetings] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);
  const [menuIndex, setMenuIndex] = useState(null);

  const [sentStatus, setSentStatus] = useState({});
  const [confirmIndex, setConfirmIndex] = useState(null);

  const handleAddOrUpdate = (meeting) => {
    if (editingIndex !== null) {
      const updated = [...meetings];
      updated[editingIndex] = meeting;
      setMeetings(updated);
      setEditingIndex(null);
    } else {
      setMeetings((prev) => [...prev, meeting]);
    }
    setOpen(false);
  };

  const handleEdit = (index) => {
    setEditingIndex(index);
    setOpen(true);
    setMenuIndex(null);
  };

  const handleDelete = (index) => {
    if (!window.confirm("Are you sure you want to delete this meeting?")) return;
    setMeetings((prev) => prev.filter((_, i) => i !== index));
    setMenuIndex(null);
  };

  const confirmSendMeeting = () => {
    setSentStatus((prev) => ({
      ...prev,
      [confirmIndex]: true,
    }));
    setConfirmIndex(null);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Meeting Schedule</h1>
          <p className="text-sm text-gray-500">
            Manage interviews and assessments
          </p>
        </div>

        <button
          onClick={() => {
            setEditingIndex(null);
            setOpen(true);
          }}
          className="bg-black text-white px-4 py-2 rounded-lg"
        >
          + Schedule Meeting
        </button>
      </div>

      {/* Meetings List */}
      <div className="bg-white border rounded-xl p-5 space-y-4">
        <h2 className="text-lg font-semibold">Upcoming Meetings</h2>

        {meetings.length === 0 ? (
          <p className="text-gray-400">No meetings scheduled yet.</p>
        ) : (
          meetings.map((m, index) => (
            <div
              key={index}
              className="border rounded-xl p-4 flex justify-between relative"
            >
              {/* LEFT CONTENT */}
              <div className="space-y-2">
                {/* ✅ Candidate Info */}
                <div>
                  <h3 className="font-semibold text-base">
                    {m.candidateName}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {m.position}
                  </p>
                  <p className="text-xs text-gray-400">
                    {m.email}
                  </p>
                </div>

                {/* Interview Info */}
                <div className="flex gap-2 items-center pt-2">
                  <h4 className="font-medium">{m.interviewType}</h4>
                  <span className="text-xs px-2 py-1 border rounded-full">
                    {m.duration} min
                  </span>
                </div>

                <p className="text-sm text-gray-500">
                  {m.date} at {m.time}
                </p>

                <div className="flex gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Video size={14} /> {m.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={14} /> {m.interviewer}
                  </span>
                </div>
              </div>

              {/* ✅ Send Meeting */}
              <div className="absolute right-12 top-4">
                {!sentStatus[index] ? (
                  <button
                    onClick={() => setConfirmIndex(index)}
                    className="bg-black text-white px-3 py-1.5 rounded-lg text-sm flex gap-2"
                  >
                    <Send size={14} />
                    Send Meeting
                  </button>
                ) : (
                  <span className="text-green-600 font-medium text-sm">
                    ✅ Meeting Schedule Sent
                  </span>
                )}
              </div>

              {/* Menu */}
              <div className="relative">
                <button
                  onClick={() =>
                    setMenuIndex(menuIndex === index ? null : index)
                  }
                  className="p-1 rounded hover:bg-gray-100"
                >
                  <MoreVertical size={18} />
                </button>

                {menuIndex === index && (
                  <div className="absolute right-0 mt-2 bg-white border rounded shadow w-32 z-20">
                    <button
                      onClick={() => handleEdit(index)}
                      className="block w-full px-4 py-2 text-left hover:bg-gray-100"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(index)}
                      className="block w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100"
                    >
                      Delete
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}

        {Object.values(sentStatus).includes(true) && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
            Meeting schedule email sent successfully.
          </div>
        )}
      </div>

      {/* ✅ CONFIRM SEND MEETING MODAL */}
      {confirmIndex !== null && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-[520px] rounded-2xl p-6 relative">
            <button
              onClick={() => setConfirmIndex(null)}
              className="absolute right-4 top-4 text-gray-400"
            >
              <X size={18} />
            </button>

            <h2 className="text-xl font-semibold mb-6">
              Send Meeting Schedule
            </h2>

            <div className="bg-gray-50 rounded-xl p-5 space-y-3 mb-6 text-sm">
              <p><b>Candidate:</b> {meetings[confirmIndex]?.candidateName}</p>
              <p><b>Position:</b> {meetings[confirmIndex]?.position}</p>
              <p><b>Email:</b> {meetings[confirmIndex]?.email}</p>
              <hr />
              <p><b>Interview:</b> {meetings[confirmIndex]?.interviewType}</p>
              <p><b>Date & Time:</b> {meetings[confirmIndex]?.date} at {meetings[confirmIndex]?.time}</p>
            </div>

            <div className="flex justify-end gap-4">
              <button
                onClick={() => setConfirmIndex(null)}
                className="px-6 py-3 border rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={confirmSendMeeting}
                className="px-8 py-3 bg-black text-white rounded-xl"
              >
                Send Meeting
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Meeting Modal */}
      {open && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden">
            <div className="overflow-y-auto max-h-[90vh] p-6">
              <ScheduleMeeting
                initialData={
                  editingIndex !== null ? meetings[editingIndex] : null
                }
                onSchedule={handleAddOrUpdate}
                onClose={() => setOpen(false)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}