// import { useState } from "react";
// import * as XLSX from "xlsx";

// import SummaryCards from "../components/reports/SummaryCards";
// import FunnelChart from "../components/reports/FunnelChart";
// import MonthlyTrendsChart from "../components/reports/MonthlyTrendsChart";
// import SourcePieChart from "../components/reports/SourcePieChart";
// import PracticePieChart from "../components/reports/PracticePieChart";
// import TopPositionsChart from "../components/reports/TopPositionsChart";

// import { reportsMock } from "../api/reportsMock";
// import { FiDownload, FiChevronDown } from "react-icons/fi";

// export default function Reports() {
//   const data = reportsMock;

//   const [period, setPeriod] = useState("Last 6 Months");
//   const [open, setOpen] = useState(false);

//   const periods = [
//     "Last 7 Days",
//     "Last 30 Days",
//     "Last 3 Months",
//     "Last 6 Months",
//     "Last 12 Months",
//   ];

//   /* ✅ EXCEL EXPORT HANDLER */
//   const handleExportExcel = () => {
//     const workbook = XLSX.utils.book_new();

//     // 1️⃣ Summary Sheet
//     const summarySheet = XLSX.utils.json_to_sheet([
//       {
//         Metric: "Total Candidates",
//         Value: data.summary.totalCandidates,
//       },
//       {
//         Metric: "Success Rate",
//         Value: `${data.summary.successRate}%`,
//       },
//       {
//         Metric: "Avg. Time to Hire",
//         Value: `${data.summary.avgTimeToHire} days`,
//       },
//       {
//         Metric: "Drop-off Rate",
//         Value: `${data.summary.dropOffRate}%`,
//       },
//     ]);
//     XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");

//     // 2️⃣ Funnel Sheet
//     const funnelSheet = XLSX.utils.json_to_sheet(data.funnel);
//     XLSX.utils.book_append_sheet(workbook, funnelSheet, "Recruitment Funnel");

//     // 3️⃣ Monthly Trends Sheet
//     const trendsSheet = XLSX.utils.json_to_sheet(data.monthlyTrends);
//     XLSX.utils.book_append_sheet(workbook, trendsSheet, "Monthly Trends");

//     // 4️⃣ Source Distribution Sheet
//     const sourceSheet = XLSX.utils.json_to_sheet(data.sourceDistribution);
//     XLSX.utils.book_append_sheet(workbook, sourceSheet, "Source Distribution");

//     // 5️⃣ Practice Distribution Sheet
//     const practiceSheet = XLSX.utils.json_to_sheet(data.practiceDistribution);
//     XLSX.utils.book_append_sheet(workbook, practiceSheet, "Practice Distribution");

//     // 6️⃣ Top Positions Sheet
//     const positionsSheet = XLSX.utils.json_to_sheet(data.topPositions);
//     XLSX.utils.book_append_sheet(workbook, positionsSheet, "Top Positions");

//     // ✅ Download file
//     XLSX.writeFile(
//       workbook,
//       `Reports_${period.replaceAll(" ", "_")}.xlsx`
//     );
//   };

//   return (
//     <div className="p-6 space-y-6">
//       {/* Header */}
//       <div className="flex justify-between items-center">
//         <div>
//           <h1 className="text-2xl font-semibold">Reports & Analytics</h1>
//           <p className="text-gray-500">
//             Comprehensive recruitment insights and metrics
//           </p>
//         </div>

//         {/* Controls */}
//         <div className="flex items-center gap-3 relative">
//           {/* Period Dropdown */}
//           <div className="relative">
//             <button
//               onClick={() => setOpen(!open)}
//               className="
//                 flex items-center justify-between gap-2
//                 px-4 py-2 min-w-[170px]
//                 border border-gray-300
//                 rounded-lg
//                 text-sm font-medium
//                 bg-white
//                 hover:bg-gray-50
//               "
//             >
//               {period}
//               <FiChevronDown className="text-gray-500" />
//             </button>

//             {open && (
//               <div className="absolute right-0 mt-2 w-full bg-white border rounded-lg shadow-md z-20">
//                 {periods.map(option => (
//                   <button
//                     key={option}
//                     onClick={() => {
//                       setPeriod(option);
//                       setOpen(false);
//                     }}
//                     className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100"
//                   >
//                     {option}
//                   </button>
//                 ))}
//               </div>
//             )}
//           </div>

//           {/* ✅ EXPORT EXCEL */}
//           <button
//             onClick={handleExportExcel}
//             className="
//               flex items-center gap-2
//               px-4 py-2
//               border border-gray-300
//               rounded-lg
//               text-sm font-medium
//               bg-white
//               hover:bg-gray-50
//             "
//           >
//             <FiDownload className="text-gray-700" />
//             Export Report
//           </button>
//         </div>
//       </div>

//       {/* Summary Cards */}
//       <SummaryCards summary={data.summary} />

//       {/* Charts */}
//       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
//         <FunnelChart data={data.funnel} />
//         <MonthlyTrendsChart data={data.monthlyTrends} />
//         <SourcePieChart data={data.sourceDistribution} />
//         <PracticePieChart data={data.practiceDistribution} />
//       </div>

//       {/* Top Positions */}
//       <TopPositionsChart data={data.topPositions} />
//     </div>
//   );


import { useState, useEffect } from "react";
import * as XLSX from "xlsx";

import SummaryCards from "../components/reports/SummaryCards";
import FunnelChart from "../components/reports/FunnelChart";
import MonthlyTrendsChart from "../components/reports/MonthlyTrendsChart";
import SourcePieChart from "../components/reports/SourcePieChart";
import PracticePieChart from "../components/reports/PracticePieChart";
import TopPositionsChart from "../components/reports/TopPositionsChart";

import { reportsMock } from "../api/reportsMock";
import { fetchCandidates } from "../api/candidateApi";
import { FiDownload, FiChevronDown } from "react-icons/fi";

export default function Reports() {
  const data = reportsMock;

  const [period, setPeriod] = useState("Last 6 Months");
  const [open, setOpen] = useState(false);

  // ✅ REAL TOTAL CANDIDATES FROM DB
  const [totalCandidates, setTotalCandidates] = useState(0);

  useEffect(() => {
    fetchCandidates()
      .then((res) => setTotalCandidates(res.length))
      .catch(console.error);
  }, []);

  // ✅ SUMMARY DATA (ONLY WHAT WE KNOW FROM DB FOR NOW)
  const summary = {
    totalCandidates,
    successRate: "--",
    avgTimeToHire: "--",
    dropOffRate: "--",
  };

  const periods = [
    "Last 7 Days",
    "Last 30 Days",
    "Last 3 Months",
    "Last 6 Months",
    "Last 12 Months",
  ];

  /* ✅ EXCEL EXPORT */
  const handleExportExcel = () => {
    const workbook = XLSX.utils.book_new();

    const summarySheet = XLSX.utils.json_to_sheet([
      { Metric: "Total Candidates", Value: summary.totalCandidates },
      { Metric: "Success Rate", Value: summary.successRate },
      { Metric: "Avg. Time to Hire", Value: summary.avgTimeToHire },
      { Metric: "Drop-off Rate", Value: summary.dropOffRate },
    ]);

    XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");
    XLSX.writeFile(workbook, `Reports_${period.replaceAll(" ", "_")}.xlsx`);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Reports & Analytics</h1>
          <p className="text-gray-500">
            Comprehensive recruitment insights and metrics
          </p>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setOpen(!open)}
              className="flex items-center justify-between gap-2 px-4 py-2 min-w-[170px] border rounded-lg bg-white"
            >
              {period}
              <FiChevronDown />
            </button>

            {open && (
              <div className="absolute right-0 mt-2 w-full bg-white border rounded-lg shadow z-20">
                {periods.map((p) => (
                  <button
                    key={p}
                    onClick={() => {
                      setPeriod(p);
                      setOpen(false);
                    }}
                    className="block w-full px-4 py-2 text-left hover:bg-gray-100"
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={handleExportExcel}
            className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50"
          >
            <FiDownload />
            Export Report
          </button>
        </div>
      </div>

      {/* ✅ SUMMARY WITH REAL TOTAL CANDIDATES */}
      <SummaryCards summary={summary} />

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FunnelChart data={data.funnel} />
        <MonthlyTrendsChart data={data.monthlyTrends} />
        <SourcePieChart data={data.sourceDistribution} />
        <PracticePieChart data={data.practiceDistribution} />
      </div>

      <TopPositionsChart data={data.topPositions} />
    </div>
  );
}