// import { useState } from "react";
// import { Plus, Upload, Search, MoreVertical } from "lucide-react";
// import AddCandidateModal from "../components/AddCandidateModal";
// import UploadResultModal from "../components/UploadResultModal";

// import {
//   fetchCandidates,
//   addCandidateApi,
//   updateCandidateApi,
//   deleteCandidateApi,
// } from "../api/candidateApi";


// export default function Candidates() {
//   const [modal, setModal] = useState(null); // add | upload | edit
//   const [candidates, setCandidates] = useState([]);
//   const [selectedIndex, setSelectedIndex] = useState(null);
//   const [menuIndex, setMenuIndex] = useState(null);

//   /* Add / Update Candidate */
//   const handleSaveCandidate = (candidate) => {
//     if (modal === "edit") {
//       const updated = [...candidates];
//       updated[selectedIndex] = candidate;
//       setCandidates(updated);
//     } else {
//       setCandidates((prev) => [...prev, candidate]);
//     }
//     setModal(null);
//   };

//   const handleExcelUpload = (excelData) => {
//   const formatted = excelData.map((row) => ({
//     name: row["Candidate Name"],
//     email: row["Email"],
//     position: row["Position"],
//     source: row["Source"],
//     practice: row["Practice"],
//     type: row["Type"],
//     // stage: row["Stage"],
//     // status: row["Status"],
//     applied: excelDateToJSDate(row["Applied Date"]),
//   }));

//   setCandidates((prev) => [...prev, ...formatted]);
// };

// const excelDateToJSDate = (serial) => {
//   if (!serial) return "";

//   const utcDays = Math.floor(serial - 25569);
//   const utcValue = utcDays * 86400;
//   const dateInfo = new Date(utcValue * 1000);

//   return dateInfo.toLocaleDateString("en-GB"); // dd/mm/yyyy
// };
//   /* Delete Candidate */
//   const handleDelete = (index) => {
//     const confirm = window.confirm("Are you sure you want to delete?");
//     if (!confirm) return;

//     setCandidates((prev) => prev.filter((_, i) => i !== index));
//     setMenuIndex(null);
//   };

//   /* Status Color */
// //   const getStatusStyles = (status) => {
// //     if (status === "Pass") return "bg-green-100 text-green-700";
// //     if (status === "Fail") return "bg-red-100 text-red-700";
// //     return "bg-yellow-100 text-yellow-700";
// //   };

//   return (
//     <div className="p-6 space-y-6">
//       {/* Header */}
//       <div className="flex justify-between items-center">
//         <div>
//           <h1 className="text-2xl font-semibold">Candidates</h1>
//           <p className="text-sm text-gray-500">
//             Manage candidate pipeline and progression
//           </p>
//         </div>

//         <div className="flex gap-3">
//           <button
//             onClick={() => setModal("upload")}
//             className="flex items-center gap-2 px-4 py-2 border rounded-lg"
//           >
//             <Upload size={16} />
//             Bulk Upload
//           </button>

//           <button
//             onClick={() => setModal("add")}
//             className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg"
//           >
//             <Plus size={16} />
//             Add Candidate
//           </button>
//         </div>
//       </div>

//       {/* Search */}
//       <div className="relative">
//         <Search className="absolute left-3 top-3 text-gray-400" size={18} />
//         <input
//           placeholder="Search candidates..."
//           className="w-full pl-10 p-3 bg-gray-100 rounded-lg"
//         />
//       </div>

//       {/* Table */}
//       <div className="bg-white border rounded-xl overflow-visible">
//         <table className="w-full text-sm">
//           <thead className="bg-gray-50">
//             <tr>
//               <th className="p-4 text-left">Candidate</th>
//               <th className="p-4">Position</th>
//               <th className="p-4">Source</th>
//               <th className="p-4">Practice / Type</th>
//               {/* <th className="p-4">Stage</th>
//               <th className="p-4">Status</th> */}
//               <th className="p-4">Applied</th>
//               <th className="p-4"></th>
//             </tr>
//           </thead>

//           <tbody>
//             {candidates.length === 0 ? (
//               <tr>
//                 <td colSpan="8" className="p-6 text-center text-gray-400">
//                   No candidates added yet
//                 </td>
//               </tr>
//             ) : (
//               candidates.map((c, i) => (
//                 <tr key={i} className="border-t relative">
//                   <td className="p-4">
//                     <div className="font-medium">{c.name}</div>
//                     <div className="text-xs text-gray-500">{c.email}</div>
//                   </td>

//                   <td className="p-4">{c.position}</td>
//                   <td className="p-4">{c.source}</td>

//                   <td className="p-4">
//                     {c.practice}
//                     <div className="text-xs text-gray-500">{c.type}</div>
//                   </td>

//                   {/* <td className="p-4">
//                     <span className="bg-black text-white text-xs px-2 py-1 rounded">
//                       {c.stage}
//                     </span>
//                   </td>

//                   <td className="p-4">
//                     <span
//                       className={`text-xs px-2 py-1 rounded ${getStatusStyles(
//                         c.status
//                       )}`}
//                     >
//                       {c.status}
//                     </span>
//                   </td> */}

//                   <td className="p-4">{c.applied}</td>

//                   {/* 3 DOT MENU */}
//                   <td className="p-4 relative">
//   <button
//     onClick={() => setMenuIndex(menuIndex === i ? null : i)}
//     className="p-1 rounded hover:bg-gray-100"
//   >
//     <MoreVertical size={16} />
//   </button>

//   {menuIndex === i && (
//     <div
//       className="
//         absolute
//         right-0
//         top-full
//         mt-2
//         w-32
//         bg-white
//         border
//         rounded-lg
//         shadow-lg
//         z-50
//       "
//     >
//       <button
//         onClick={() => {
//           setSelectedIndex(i);
//           setModal('edit');
//           setMenuIndex(null);
//         }}
//         className="block w-full px-4 py-2 text-left hover:bg-gray-100"
//       >
//         Edit
//       </button>

//       <button
//         onClick={() => handleDelete(i)}
//         className="block w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100"
//       >
//         Delete
//       </button>
//     </div>
//   )}
// </td>

//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>

//       {/* Modals */}
//       {modal && (
//         <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
//           <div className="bg-white w-full max-w-xl rounded-2xl max-h-[90vh] overflow-hidden">
//             <div className="overflow-y-auto max-h-[90vh] p-6">
//               {(modal === "add" || modal === "edit") && (
//                 <AddCandidateModal
//                   initialData={modal === "edit" ? candidates[selectedIndex] : null}
//                   onAdd={handleSaveCandidate}
//                   onClose={() => setModal(null)}
//                 />
//               )}
              
//             {modal === "upload" && (
//             <UploadResultModal
//                 onClose={() => setModal(null)}
//                 onUpload={handleExcelUpload}
//             />
//             )}

//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }


// import { useState, useEffect } from "react";
// import { Plus, Upload, Search, MoreVertical } from "lucide-react";
// import AddCandidateModal from "../components/AddCandidateModal";
// import UploadResultModal from "../components/UploadResultModal";

// import {
//   fetchCandidates,
//   addCandidateApi,
//   updateCandidateApi,
//   deleteCandidateApi,
// } from "../api/candidateApi";

// export default function Candidates() {
//   const [modal, setModal] = useState(null);
//   const [candidates, setCandidates] = useState([]);
//   const [selectedIndex, setSelectedIndex] = useState(null);
//   const [menuIndex, setMenuIndex] = useState(null);

//   // ✅ LOAD FROM BACKEND
//   useEffect(() => {
//     fetchCandidates()
//       .then(setCandidates)
//       .catch(console.error);
//   }, []);

//   // ✅ ADD / EDIT
//   const handleSaveCandidate = async (candidate) => {
//     try {
//       if (modal === "edit") {
//         const saved = await updateCandidateApi(candidate.id, candidate);
//         setCandidates((prev) =>
//           prev.map((c) => (c.id === saved.id ? saved : c))
//         );
//       } else {
//         const saved = await addCandidateApi(candidate);
//         setCandidates((prev) => [...prev, saved]);
//       }
//       setModal(null);
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   const handleUploadSuccess = async () => {
//   const data = await fetchCandidates();
//   setCandidates(data);
// };


//   // ✅ DELETE
//   const handleDelete = async (id) => {
//     if (!window.confirm("Are you sure you want to delete?")) return;
//     try {
//       await deleteCandidateApi(id);
//       setCandidates((prev) => prev.filter((c) => c.id !== id));
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   return (
//     <div className="p-6 space-y-6">
//       <div className="flex justify-between items-center">
//         <div>
//           <h1 className="text-2xl font-semibold">Candidates</h1>
//           <p className="text-sm text-gray-500">
//             Manage candidate pipeline and progression
//           </p>
//         </div>

//         <div className="flex gap-3">
//           <button onClick={() => setModal("upload")}
//             className="flex items-center gap-2 px-4 py-2 border rounded-lg">
//             <Upload size={16} /> Bulk Upload
//           </button>

//           <button onClick={() => setModal("add")}
//             className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg">
//             <Plus size={16} /> Add Candidate
//           </button>
//         </div>
//       </div>

//       <div className="relative">
//         <Search className="absolute left-3 top-3 text-gray-400" size={18} />
//         <input placeholder="Search candidates..."
//           className="w-full pl-10 p-3 bg-gray-100 rounded-lg" />
//       </div>

//       <div className="bg-white border rounded-xl overflow-visible">
//         <table className="w-full text-sm">
//           <thead className="bg-gray-50">
//             <tr>
//               <th className="p-4 text-left">Candidate</th>
//               <th className="p-4">Position</th>
//               <th className="p-4">Source</th>
//               <th className="p-4">Practice / Type</th>
//               <th className="p-4">Applied</th>
//               <th className="p-4"></th>
//             </tr>
//           </thead>

//           <tbody>
//             {candidates.length === 0 ? (
//               <tr>
//                 <td colSpan="6" className="p-6 text-center text-gray-400">
//                   No candidates added yet
//                 </td>
//               </tr>
//             ) : (
//               candidates.map((c, i) => (
//                 <tr key={c.id} className="border-t">
//                   <td className="p-4 text-left">
//                     <div className="font-medium">{c.name}</div>
//                     <div className="text-xs text-gray-500">{c.email}</div>
//                   </td>
//                   <td className="p-4 text-left">{c.position}</td>
//                   <td className="p-4 text-left">{c.source}</td>
//                   <td className="p-4">
//                     {c.practice}
//                     <div className="text-xs text-gray-500">{c.type}</div>
//                   </td>
//                   <td className="p-4 text-left">{c.applied}</td>

//                   <td className="p-4 relative">
//                     <button
//                       onClick={() =>
//                         setMenuIndex(menuIndex === i ? null : i)
//                       }>
//                       <MoreVertical size={16} />
//                     </button>

//                     {menuIndex === i && (
//                       <div className="absolute right-0 mt-2 w-28 bg-white border rounded shadow z-50">
//                         <button
//                           onClick={() => {
//                             setSelectedIndex(i);
//                             setModal("edit");
//                             setMenuIndex(null);
//                           }}
//                           className="block w-full px-4 py-2 text-left hover:bg-gray-100">
//                           Edit
//                         </button>

//                         <button
//                           onClick={() => handleDelete(c.id)}
//                           className="block w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100">
//                           Delete
//                         </button>
//                       </div>
//                     )}
//                   </td>
//                 </tr>
//               ))
//             )}
//           </tbody>
//         </table>
//       </div>

//       {modal && (
//         <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
//           <div className="bg-white w-full max-w-xl rounded-2xl p-6">
//             {(modal === "add" || modal === "edit") && (
//               <AddCandidateModal
//                 initialData={
//                   modal === "edit" ? candidates[selectedIndex] : null
//                 }
//                 onAdd={handleSaveCandidate}
//                 onClose={() => setModal(null)}
//               />
//             )}
//             {modal === "upload" && (
//             //   <UploadResultModal
//             //     onClose={() => setModal(null)}
//             //     onUpload={() => {}}
//             //   />
//             <UploadResultModal
//                 onClose={() => setModal(null)}
//                 onUploadSuccess={handleUploadSuccess}
//                 />

//             )}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }


import { useState, useEffect } from "react";
import { Plus, Upload, Search, MoreVertical } from "lucide-react";

import AddCandidateModal from "../components/AddCandidateModal";
import UploadResultModal from "../components/UploadResultModal";
import SummaryCards from "../components/reports/SummaryCards";

import {
  fetchCandidates,
  addCandidateApi,
  updateCandidateApi,
  deleteCandidateApi,
} from "../api/candidateApi";

export default function Candidates() {
  const [modal, setModal] = useState(null);
  const [candidates, setCandidates] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [menuIndex, setMenuIndex] = useState(null);

  // ✅ LOAD CANDIDATES FROM BACKEND
  useEffect(() => {
    fetchCandidates()
      .then(setCandidates)
      .catch(console.error);
  }, []);

  // ✅ SUMMARY FROM REAL DB DATA
  const summary = {
    totalCandidates: candidates.length,
  };

  // ✅ ADD / EDIT CANDIDATE
  const handleSaveCandidate = async (candidate) => {
    try {
      if (modal === "edit") {
        const saved = await updateCandidateApi(candidate.id, candidate);
        setCandidates((prev) =>
          prev.map((c) => (c.id === saved.id ? saved : c))
        );
      } else {
        const saved = await addCandidateApi(candidate);
        setCandidates((prev) => [...prev, saved]);
      }
      setModal(null);
    } catch (err) {
      console.error(err);
    }
  };

  // ✅ AFTER BULK UPLOAD REFRESH
  const handleUploadSuccess = async () => {
    const data = await fetchCandidates();
    setCandidates(data);
  };

  // ✅ DELETE CANDIDATE
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete?")) return;

    try {
      await deleteCandidateApi(id);
      setCandidates((prev) => prev.filter((c) => c.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-6 space-y-6">

      {/* ✅ SUMMARY CARDS */}
      {/* <SummaryCards summary={summary} /> */}

      {/* HEADER */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Candidates</h1>
          <p className="text-sm text-gray-500">
            Manage candidate pipeline and progression
          </p>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => setModal("upload")}
            className="flex items-center gap-2 px-4 py-2 border rounded-lg"
          >
            <Upload size={16} />
            Bulk Upload
          </button>

          <button
            onClick={() => setModal("add")}
            className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg"
          >
            <Plus size={16} />
            Add Candidate
          </button>
        </div>
      </div>

      {/* SEARCH */}
      <div className="relative">
        <Search className="absolute left-3 top-3 text-gray-400" size={18} />
        <input
          placeholder="Search candidates..."
          className="w-full pl-10 p-3 bg-gray-100 rounded-lg"
        />
      </div>

      {/* TABLE */}
      <div className="bg-white border rounded-xl overflow-visible">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-4 text-left">Candidate</th>
              <th className="p-4 text-left">Position</th>
              <th className="p-4 text-left">Source</th>
              <th className="p-4 text-left">Practice / Type</th>
              <th className="p-4 text-left">Applied</th>
              <th className="p-4"></th>
            </tr>
          </thead>

          <tbody>
            {candidates.length === 0 ? (
              <tr>
                <td colSpan="6" className="p-6 text-center text-gray-400">
                  No candidates added yet
                </td>
              </tr>
            ) : (
              candidates.map((c, i) => (
                <tr key={c.id} className="border-t">
                  <td className="p-4">
                    <div className="font-medium">{c.name}</div>
                    <div className="text-xs text-gray-500">{c.email}</div>
                  </td>

                  <td className="p-4">{c.position}</td>
                  <td className="p-4">{c.source}</td>

                  <td className="p-4">
                    {c.practice}
                    <div className="text-xs text-gray-500">
                      {c.type}
                    </div>
                  </td>

                  <td className="p-4">{c.applied}</td>

                  <td className="p-4 relative">
                    <button
                      onClick={() =>
                        setMenuIndex(menuIndex === i ? null : i)
                      }
                    >
                      <MoreVertical size={16} />
                    </button>

                    {menuIndex === i && (
                      <div className="absolute right-0 mt-2 w-28 bg-white border rounded shadow z-50">
                        <button
                          onClick={() => {
                            setSelectedIndex(i);
                            setModal("edit");
                            setMenuIndex(null);
                          }}
                          className="block w-full px-4 py-2 text-left hover:bg-gray-100"
                        >
                          Edit
                        </button>

                        <button
                          onClick={() => handleDelete(c.id)}
                          className="block w-full px-4 py-2 text-left text-red-600 hover:bg-gray-100"
                        >
                          Delete
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* MODALS */}
      {modal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-full max-w-xl rounded-2xl p-6">
            {(modal === "add" || modal === "edit") && (
              <AddCandidateModal
                initialData={
                  modal === "edit" ? candidates[selectedIndex] : null
                }
                onAdd={handleSaveCandidate}
                onClose={() => setModal(null)}
              />
            )}

            {modal === "upload" && (
              <UploadResultModal
                onClose={() => setModal(null)}
                onUploadSuccess={handleUploadSuccess}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}